package Redirectors;

import DataAccess.AccessProxy;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ListaServlet", urlPatterns = {"/logged_in/lista/"})
public class ListaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[ListaServlet] doGet");

        request.setAttribute("nomi_oggetti", AccessProxy.GetObjectsNames(123,234));

        RequestDispatcher dispatcher = request.getRequestDispatcher("/logged_in/lista/Lista.jsp");
        if (dispatcher != null){
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[ListaServlet] doPost");

        String id_oggetto = request.getParameter("id_oggetto");
        String button_pushed = request.getParameter("button_pushed");

        ServletContext context=getServletContext();

        if (id_oggetto != null) {
            System.out.println("[ListaServlet] Rimuovi id_oggetto: "+id_oggetto);

            // TO DO

            response.sendRedirect("/logged_in/lista/");
        }
        if (button_pushed != null) {
            if (button_pushed.equals("rinomina_lista")) {
                System.out.println("[ListaServlet] Rinomina lista");

                // TO DO

                response.sendRedirect("/logged_in/lista/");
            }
            else if (button_pushed.equals("elimina_lista")) {
                System.out.println("[ListaServlet] Elimina lista");

                // TO DO

                response.sendRedirect("/logged_in/dashboard/");
            }
            else if (button_pushed.equals("aggiungi_oggetto")) {
                System.out.println("[ListaServlet] Aggiungi oggetto");

                // TO DO

                response.sendRedirect("/logged_in/lista/");
            }
        }
    }
}