package Redirectors;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import DataAccess.AccessProxy;

@WebServlet(name = "DashboardServlet", urlPatterns = {"/logged_in/dashboard/"})
public class DashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[DashboardServlet] doGet");

        request.setAttribute("nomi_liste", AccessProxy.GetPersonalListsNames(123));
        request.setAttribute("nomi_gruppi", AccessProxy.GetPersonalGroupsNames(123));

        RequestDispatcher dispatcher = request.getRequestDispatcher("/logged_in/dashboard/Dashboard.jsp");
        if (dispatcher != null){
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[DashboardServlet] doPost");

        String id_lista = request.getParameter("id_lista");
        String id_gruppo = request.getParameter("id_gruppo");
        String button_pushed = request.getParameter("button_pushed");

        ServletContext context=getServletContext();

        if (id_lista != null) {
            context.setAttribute("id_lista",id_lista);
            System.out.println("[DashboardServlet] Visualizza id_lista: "+id_lista);
            response.sendRedirect("/logged_in/lista/");
        }
        if (id_gruppo != null) {
            context.setAttribute("id_gruppo",id_gruppo);
            System.out.println("[DashboardServlet] Visualizza id_gruppo: "+id_gruppo);
            response.sendRedirect("/logged_in/gruppo/");
        }
        if (button_pushed != null) {
            if (button_pushed.equals("nuova_lista")) {
                System.out.println("[DashboardServlet] Nuova lista");

                // TO DO

                response.sendRedirect("/logged_in/dashboard/");
            }
            else if (button_pushed.equals("nuovo_gruppo")) {
                System.out.println("[DashboardServlet] Nuovo gruppo");

                // TO DO

                response.sendRedirect("/logged_in/dashboard/");
            }
        }
    }
}
