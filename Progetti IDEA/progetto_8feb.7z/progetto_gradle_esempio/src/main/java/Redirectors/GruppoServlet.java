package Redirectors;

import DataAccess.AccessProxy;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "GruppoServlet", urlPatterns = {"/logged_in/gruppo/"})
public class GruppoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[GruppoServlet] doGet");

        request.setAttribute("nomi_partecipanti", AccessProxy.GetPartecipantsNames(123,234));
        request.setAttribute("nomi_liste", AccessProxy.GetSharedListsNames(123,234));

        RequestDispatcher dispatcher = request.getRequestDispatcher("/logged_in/gruppo/Gruppo.jsp");
        if (dispatcher != null){
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[GruppoServlet] doPost");

        String id_partecipante = request.getParameter("id_partecipante");
        String id_lista = request.getParameter("id_lista");
        String button_pushed = request.getParameter("button_pushed");

        ServletContext context=getServletContext();

        if (id_partecipante != null) {
            System.out.println("[GruppoServlet] Rimuovi id_partecipante: "+id_partecipante);

            // TO DO

            response.sendRedirect("/logged_in/gruppo/");
        }
        if (id_lista != null) {
            System.out.println("[GruppoServlet] Rimuovi id_lista: "+id_lista);

            // TO DO

            response.sendRedirect("/logged_in/gruppo/");
        }
        if (button_pushed != null) {
            if (button_pushed.equals("rinomina_gruppo")) {
                System.out.println("[GruppoServlet] Rinomina gruppo");

                // TO DO

                response.sendRedirect("/logged_in/gruppo/");
            }
            else if (button_pushed.equals("elimina_gruppo")) {
                System.out.println("[GruppoServlet] Elimina gruppo");

                // TO DO

                response.sendRedirect("/logged_in/dashboard/");
            }
            else if (button_pushed.equals("aggiungi_partecipante")) {
                System.out.println("[GruppoServlet] Aggiungi partecipante");

                // TO DO

                response.sendRedirect("/logged_in/gruppo/");
            }
        }
    }
}