package DataAccess;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import Authorization.AuthorizationController;

/*
    -Verifica che l'operazione richiesta sia autorizzata, mediante un oggetto AuthorizationController,
    e poi interagisce con il DB.

    MEMO: di volta in volta bisognerà levare le parole chiave static
*/

public class AccessProxy {

    private AuthorizationController controller;

    public AccessProxy() {
        controller = new AuthorizationController();
    }

    /*
    Serve per ricavare i nomi delle liste di cui è proprietario l'utente
     */
    public ArrayList<String> GetPersonalListsNames(Integer id_utente) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome lista 1");
        String name_2 = new String("Nome lista 2");
        String name_3 = new String("Nome lista 3");

        ArrayList<String> names = new ArrayList<String>();
        names.add(name_1);
        names.add(name_2);
        names.add(name_3);

        return names;
    }

    /*
    Server per ricavare i nomi dei gruppi di cui l'utente è proprietario o a cui partecipa
     */
    public ArrayList<String> GetPersonalGroupsNames(Integer id_utente) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome gruppo 1");
        String name_2 = new String("Nome gruppo 2");
        String name_3 = new String("Nome gruppo 3");

        ArrayList<String> names = new ArrayList<String>();
        names.add(name_1);
        names.add(name_2);
        names.add(name_3);

        return names;
    }

    /*
    Serve per inserire una nuova lista vuota nel DB
     */
    public static Boolean NewList(String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per inserire un nuovo gruppo vuoto nel DB
     */
    public static Boolean NewGroup(String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per ottenere i nomi degli oggetti contenuti in una lista
     */
    public static ArrayList<String> GetObjectsNames(Integer id_utente, Integer id_lista) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome oggetto 1");
        String name_2 = new String("Nome oggetto 2");
        String name_3 = new String("Nome oggetto 3");
        String name_4 = new String("Nome oggetto 4");
        String name_5 = new String("Nome oggetto 5");

        ArrayList<String> names = new ArrayList<String>();
        names.add(name_1);
        names.add(name_2);
        names.add(name_3);
        names.add(name_4);
        names.add(name_5);

        return names;
    }

    /*
    Serve per rimuovere una lista dal DB
     */
    public String RemoveList(Integer id_utente, Integer id_lista) {

        // Verifica se l'operazione è consentita
        String result = controller.RemoveList(id_utente,id_lista);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }

    }

    /*
    Serve per rinominare una lista nel DB
     */
    public static Boolean RenameList(Integer id_utente, Integer id_lista, String nuovo_nome) {
        // TO DO
        return true;
    }

    /*
    Serve per aggiungere un elemento ad una lista nel DB
     */
    public static Boolean AddElement(Integer id_utente, Integer id_lista, String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per rimuovere un elemento da una lista nel DB
     */
    public static Boolean RemoveElement(Integer id_utente, Integer id_lista, Integer id_elemento) {
        // TO DO
        return true;
    }

    /*
    Serve per ricavare i nomi dei partecipanti a un gruppo dal DB
     */
    public static ArrayList<String> GetPartecipantsNames(Integer id_utente, Integer id_gruppo) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome partecipante 1");
        String name_2 = new String("Nome partecipante 2");
        String name_3 = new String("Nome partecipante 3");

        ArrayList<String> names = new ArrayList<String>();
        names.add(name_1);
        names.add(name_2);
        names.add(name_3);

        return names;
    }

    /*
    Serve per ricavare i nomi delle liste condivise con un gruppo dal DB
     */
    public static ArrayList<String> GetSharedListsNames(Integer id_utente, Integer id_gruppo) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome lista 1");
        String name_2 = new String("Nome lista 2");
        String name_3 = new String("Nome lista 3");
        String name_4 = new String("Nome lista 4");
        String name_5 = new String("Nome lista 5");

        ArrayList<String> names = new ArrayList<String>();
        names.add(name_1);
        names.add(name_2);
        names.add(name_3);
        names.add(name_4);
        names.add(name_5);

        return names;
    }

    /*
    Serve per aggiungere partecipanti a un gruppo sul DB
     */
    public static Boolean AddPartecipant(Integer id_utente, Integer id_gruppo, Integer id_nuovo_utente) {
        // TO DO
        return true;
    }

    /*
    Serve per rimuovere un partecipante da un gruppo sul DB
     */
    public static Boolean RemovePartecipant (Integer id_utente, Integer id_gruppo, Integer id_utente_eliminato) {
        // TO DO
        return true;
    }

}
