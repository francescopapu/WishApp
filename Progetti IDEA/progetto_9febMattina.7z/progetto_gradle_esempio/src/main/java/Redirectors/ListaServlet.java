package Redirectors;

import DataAccess.AccessProxy;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/*
    -Serve per gestite le richieste GET (visione delle pagine via browser) e POST (pressione dei pulsanti)
    destinate alla pagina relativa a una lista
*/

@WebServlet(name = "ListaServlet", urlPatterns = {"/logged_in/lista/"})
public class ListaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[ListaServlet] doGet");

        // -Controlla se l'AccessProxy relativo alla sessione è già inizializzato e in caso contrario
        // lo inizializza
        HttpSession session = request.getSession();
        AccessProxy access_proxy = (AccessProxy) session.getAttribute("access_proxy");
        if (access_proxy != null) {
            System.out.println("[ListaServlet] AccessProxy presente");
        } else {
            access_proxy = new AccessProxy();
            session.setAttribute("access_proxy", access_proxy);
            System.out.println("[ListaServlet] AccessProxy inizializzato");
        }

        // Preleva i nomi degli oggetti contenuti nella lista corrente e li inserisce nella richiesta
        // che poi verrà inoltrata alla pagina .jsp
        request.setAttribute("nomi_oggetti", access_proxy.GetObjectsNames(123,234));

        // Inoltra la richiesta GET alla pagina .jsp corrispondente
        RequestDispatcher dispatcher = request.getRequestDispatcher("/logged_in/lista/Lista.jsp");
        if (dispatcher != null){
            dispatcher.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[ListaServlet] doPost");

        // Estrae i parametri dalla richiesta POST
        String id_oggetto = request.getParameter("id_oggetto");
        String button_pushed = request.getParameter("button_pushed");

        // Ricava l'oggetto session
        HttpSession session = request.getSession();

        // Effettua le operazioni opportune in base al pulsante premuto
        if (id_oggetto != null) {
            System.out.println("[ListaServlet] Rimuovi id_oggetto: "+id_oggetto);

            // TO DO

            response.sendRedirect("/logged_in/lista/");
        }
        if (button_pushed != null) {
            if (button_pushed.equals("rinomina_lista")) {
                System.out.println("[ListaServlet] Rinomina lista");

                // TO DO

                response.sendRedirect("/logged_in/lista/");
            }
            else if (button_pushed.equals("elimina_lista")) {
                System.out.println("[ListaServlet] Elimina lista");

                AccessProxy access_proxy = (AccessProxy) session.getAttribute("access_proxy");
                String result = access_proxy.RemoveList(123, 123);

                if (result.equals("Permit")) {//permit
                    System.out.println("[ListaServlet] Elimina lista permesso");
                } else if (result.equals("Deny")) {//deny
                    System.out.println("[ListaServlet] Elimina lista negato");
                } else if (result.equals("Indeterminate")) {//indeterminate
                    System.out.println("[ListaServlet] Elimina lista, valutazione xacml indeterminata");
                } else if (result.equals("NotApplicable")) {//not applicable
                    System.out.println("[ListaServlet] Elimina lista, nessuna policy xacml applicabile");
                }

                response.sendRedirect("/logged_in/dashboard/");
            }
            else if (button_pushed.equals("aggiungi_oggetto")) {
                System.out.println("[ListaServlet] Aggiungi oggetto");

                // TO DO

                response.sendRedirect("/logged_in/lista/");
            }
        }
    }
}