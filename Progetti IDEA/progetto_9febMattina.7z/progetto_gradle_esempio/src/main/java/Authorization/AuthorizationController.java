package Authorization;

import com.sun.xacml.PDP;
import com.sun.xacml.PDPConfig;
import com.sun.xacml.attr.IntegerAttribute;
import com.sun.xacml.attr.StringAttribute;
import com.sun.xacml.ctx.*;
import com.sun.xacml.finder.AttributeFinder;
import com.sun.xacml.finder.PolicyFinder;
import com.sun.xacml.finder.impl.CurrentEnvModule;
import com.sun.xacml.finder.impl.FilePolicyModule;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.FilenameFilter;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;

/*
    Inizializza il PDP e lo interroga, mediante delle funzioni che vengono invocate da un AccessProxy
*/

public class AuthorizationController {

    private PDP pdp;

    /*
    Serve per inizializzare il PDP
     */
    public AuthorizationController() {

        File[] listaFile;
        File f;
        String policyfile;
        FilePolicyModule policyModule = new FilePolicyModule();
        PolicyFinder policyFinder = new PolicyFinder();
        Set policyModules = new HashSet();

        String PATH_POLICY = "/Users/frapiet/Desktop/progetto_gradle_esempio/src/main/resources/Policies"; //path della cartella contenente le policy
        File path_directory = new File(PATH_POLICY);
        listaFile = path_directory.listFiles(new FilenameFilter() {
            public boolean accept(File path_directory, String name) {
                return name.toLowerCase().endsWith(".xml");
            }
        });

        for(int i=0;i<listaFile.length;i++)
        {
            f=listaFile[i];
            policyfile = f.getAbsolutePath();
            policyModule.addPolicy(policyfile);
            policyModules.add(policyModule);
            policyFinder.setModules(policyModules);
        }

        AttributeFinder attrFinder = new AttributeFinder();

        CurrentEnvModule envModule = new CurrentEnvModule();
        DBAttributeFinder dbAttributeFinder = new DBAttributeFinder();

        List attrModules = new ArrayList();
        attrModules.add(envModule);
        attrModules.add(dbAttributeFinder);

        attrFinder.setModules(attrModules);

        pdp = new PDP(new PDPConfig(attrFinder, policyFinder, null));
    }

    /*
    Operazione di rimozione di una lista personale da parte dell'utente
     */
    public String RemoveList(Integer id_utente, Integer id_lista) {
        try {
            // costruisco i Subjects
            HashSet subjects = new HashSet();
            HashSet attributes = new HashSet();

            IntegerAttribute id_utente_attr_val = new IntegerAttribute(id_utente);
            URI id_utente_uri = new URI("urn:progetto:names:id-utente");
            Attribute id_utente_attr = new Attribute(id_utente_uri,null,null,id_utente_attr_val);
            attributes.add(id_utente_attr);

            subjects.add(new Subject(attributes));

            //Resources
            HashSet resources = new HashSet();

            IntegerAttribute id_lista_attr_val = new IntegerAttribute(id_lista);

            URI id_lista_uri = new URI("urn:progetto:names:id-lista");
            Attribute id_lista_attr = new Attribute(id_lista_uri,null,null,id_lista_attr_val);
            resources.add(id_lista_attr);
            URI resource_id_uri = new URI("urn:oasis:names:tc:xacml:1.0:resource:resource-id");
            Attribute resource_id_attr = new Attribute(resource_id_uri,null,null,id_lista_attr_val);
            resources.add(resource_id_attr);

            StringAttribute resource_type_attr_val = new StringAttribute("Lista");
            URI resource_type_uri = new URI("urn:progetto:names:resource-type");
            Attribute resource_type_attr = new Attribute(resource_type_uri,null,null,resource_type_attr_val);
            resources.add(resource_type_attr);

            //Actions
            HashSet actions = new HashSet();

            StringAttribute action_type_attr_val = new StringAttribute("Elimina");
            URI action_type_uri = new URI("urn:progetto:names:action-type");
            Attribute action_type_attr = new Attribute(action_type_uri,null,null,action_type_attr_val);
            actions.add(action_type_attr);

            // Costruisce la richiesta
            RequestCtx XACMLrequest = new RequestCtx(subjects, resources, actions, new HashSet());

            // Interroga il pdp
            ResponseCtx XACMLresponse = pdp.evaluate(XACMLrequest);

            // Elabora la decisione
            Set ris_set = XACMLresponse.getResults();
            Result ris = null;
            Iterator it = ris_set.iterator();

            while (it.hasNext()) {
                ris = (Result) it.next();
            }
            int dec = ris.getDecision();

            if (dec == 0) {//permit
                return "Permit";
            } else if (dec == 1) {//deny
                return "Deny";
            } else if (dec == 2) {//indeterminate
                return "Indeterminate";
            } else if (dec==3) {//not applicable
                return "NotApplicable";
            }

        } catch (URISyntaxException e) {
            e.printStackTrace();
            System.out.println("[AuthorizationController] URISyntaxException");
            return null;
        }

        return null;
    }


}
