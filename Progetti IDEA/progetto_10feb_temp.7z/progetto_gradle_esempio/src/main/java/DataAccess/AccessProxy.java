package DataAccess;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import Authorization.AuthorizationController;

import PersistentObjs.*;

/*
    -Verifica che l'operazione richiesta sia autorizzata, mediante un oggetto AuthorizationController,
    e poi interagisce con il DB.

    MEMO: di volta in volta bisognerà levare le parole chiave static
*/

public class AccessProxy {

    private AuthorizationController controller;

    public AccessProxy() {
        controller = new AuthorizationController();
    }

    /*
    Serve per ricavare le liste di cui è proprietario l'utente
    (All'interno degli oggetti lista inizializza solo nome e id)
    */
    public ArrayList<Lista> GetPersonalLists(Integer id_utente) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome lista 1");
        String name_2 = new String("Nome lista 2");
        String name_3 = new String("Nome lista 3");

        Integer id_1 = new Integer(123);
        Integer id_2 = new Integer(234);
        Integer id_3 = new Integer(456);

        Lista lista_1 = new Lista(id_1,name_1);
        Lista lista_2 = new Lista(id_2,name_2);
        Lista lista_3 = new Lista(id_3,name_3);

        ArrayList<Lista> lists = new ArrayList<Lista>();

        lists.add(lista_1);
        lists.add(lista_2);
        lists.add(lista_3);

        return lists;
    }

    /*
    Server per ricavare i gruppi di cui l'utente è proprietario o a cui partecipa
    (All'interno degli oggetti gruppo inizializza solo nome e id)
    */
    public ArrayList<Gruppo> GetPersonalGroups(Integer id_utente) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome gruppo 1");
        String name_2 = new String("Nome gruppo 2");
        String name_3 = new String("Nome gruppo 3");

        Integer id_1 = new Integer(123);
        Integer id_2 = new Integer(234);
        Integer id_3 = new Integer(456);

        Gruppo gruppo_1 = new Gruppo(id_1,name_1);
        Gruppo gruppo_2 = new Gruppo(id_2,name_2);
        Gruppo gruppo_3 = new Gruppo(id_3,name_3);

        ArrayList<Gruppo> lists = new ArrayList<Gruppo>();

        lists.add(gruppo_1);
        lists.add(gruppo_2);
        lists.add(gruppo_3);

        return lists;
    }

    /*
    Serve per inserire una nuova lista vuota nel DB
     */
    public Boolean NewList(String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per inserire un nuovo gruppo vuoto nel DB
     */
    public Boolean NewGroup(String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per ottenere un'oggetto lista per la visualizzazione in Lista.jsp
    (Vengono inizializzati tutti i campi dell'oggetto lista)
    */
    public ArrayList<Lista> GetList(Integer id_utente, Integer id_lista, Integer id_gruppo) {
        // Verifica se l'operazione è consentita
        String result = controller.ViewList(id_utente,id_lista,id_gruppo);

        // Inizializzo un ArrayList, inizialmente vuoto
        ArrayList<Lista> lists = new ArrayList<Lista>();

        // La prima lista contiene solo l'esito della valutazione xacml
        Integer id_result = new Integer(0);
        Lista lista_result = new Lista(id_result,result);
        lists.add(lista_result);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // STUB dell'accesso al DB
            String name = new String("Nome lista 1");
            Integer id = id_lista;
            ArrayList<Prodotto> products = new ArrayList<Prodotto>();
            String name_1 = new String("Nome oggetto 1");
            String name_2 = new String("Nome oggetto 2");
            String name_3 = new String("Nome oggetto 3");
            Integer id_1 = new Integer(123);
            Integer id_2 = new Integer(234);
            Integer id_3 = new Integer(456);
            Prodotto prodotto_1 = new Prodotto(id_1,name_1);
            Prodotto prodotto_2 = new Prodotto(id_2,name_2);
            Prodotto prodotto_3 = new Prodotto(id_3,name_3);
            products.add(prodotto_1);
            products.add(prodotto_2);
            products.add(prodotto_3);

            Lista lista = new Lista(id, name, products);

            lists.add(lista);
        }

        return lists;
    }

    /*
    Serve per rimuovere una lista dal DB
     */
    public String RemoveList(Integer id_utente, Integer id_lista, Integer id_gruppo) {

        // Verifica se l'operazione è consentita
        String result = controller.RemoveList(id_utente,id_lista,id_gruppo);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }

    /*
    Serve per rinominare una lista nel DB
     */
    public String RenameList(Integer id_utente, Integer id_lista, Integer id_gruppo, String nuovo_nome) {

        // Verifica se l'operazione è consentita
        String result = controller.ModifyList(id_utente,id_lista, id_gruppo);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }

    /*
    Serve per aggiungere un elemento ad una lista nel DB
     */
    public String AddElement(Integer id_utente, Integer id_lista, Integer id_gruppo, String nome) {

        // Verifica se l'operazione è consentita
        String result = controller.ModifyList(id_utente,id_lista, id_gruppo);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }

    /*
    Serve per rimuovere un elemento da una lista nel DB
     */
    public String RemoveElement(Integer id_utente, Integer id_lista, Integer id_gruppo, Integer id_elemento) {

        // Verifica se l'operazione è consentita
        String result = controller.ModifyList(id_utente,id_lista, id_gruppo);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }

    /*
    Serve per ricavare i nomi dei partecipanti a un gruppo dal DB
     */
    public ArrayList<String> GetPartecipantsNames(Integer id_utente, Integer id_gruppo) {

        // Verifica se l'operazione è consentita
        String result = controller.ViewGroup(id_utente,id_gruppo);

        // inizializzo un ArrayList, inizialmente vuoto
        ArrayList<String> names = new ArrayList<String>();

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // STUB dell'accesso al DB
            String name_1 = new String("Nome partecipante 1");
            String name_2 = new String("Nome partecipante 2");
            String name_3 = new String("Nome partecipante 3");

            names.add(name_1);
            names.add(name_2);
            names.add(name_3);

            return names;
        } else {

            names.add(result);
            return names;
        }
    }

    /*
    Serve per ricavare i nomi delle liste condivise con un gruppo dal DB
     */
    public ArrayList<String> GetSharedListsNames(Integer id_utente, Integer id_gruppo) {

        // Verifica se l'operazione è consentita
        String result = controller.ViewGroup(id_utente,id_gruppo);

        // inizializzo un ArrayList, inizialmente vuoto
        ArrayList<String> names = new ArrayList<String>();

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // STUB dell'accesso al DB
            String name_1 = new String("Nome lista 1");
            String name_2 = new String("Nome lista 2");
            String name_3 = new String("Nome lista 3");
            String name_4 = new String("Nome lista 4");
            String name_5 = new String("Nome lista 5");

            names.add(name_1);
            names.add(name_2);
            names.add(name_3);
            names.add(name_4);
            names.add(name_5);

            return names;
        } else {

            names.add(result);
            return names;
        }
    }

    /*
    Serve per eliminare un gruppo sul DB
    */
    public String RemoveGroup (Integer id_utente, Integer id_gruppo_eliminato) {

        // Verifica se l'operazione è consentita
        String result = controller.RemoveGroup(id_utente,id_gruppo_eliminato);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }

    /*
    Serve per aggiungere partecipanti a un gruppo sul DB
     */
    public String AddPartecipant(Integer id_utente, Integer id_gruppo, Integer id_nuovo_utente) {

        // Verifica se l'operazione è consentita
        String result = controller.ModifyGroup(id_utente,id_gruppo);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }

    /*
    Serve per rimuovere un partecipante da un gruppo sul DB
     */
    public String RemovePartecipant (Integer id_utente, Integer id_gruppo, Integer id_utente_eliminato) {

        // Verifica se l'operazione è consentita
        String result = controller.ModifyGroup(id_utente,id_gruppo);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }

    /*
    Serve per rinominare un gruppo sul DB
     */
    public String RenameGroup (Integer id_utente, Integer id_gruppo, String nuovo_nome) {

        // Verifica se l'operazione è consentita
        String result = controller.ModifyGroup(id_utente,id_gruppo);

        // -Se l'operazione è consentita, interagisce con AceQL per eseguirla sul DB
        // -Altrimenti restituisce semplicemente il risultato dell'interrogazione XACML
        if (result.equals("Permit")) {

            // TO DO (OPERAZIONE DB)

            return result;
        } else {
            return result;
        }
    }
}
