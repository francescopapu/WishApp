package Authorization;


import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xacml.PDP;
import com.sun.xacml.PDPConfig;
import com.sun.xacml.attr.IntegerAttribute;
import com.sun.xacml.attr.StringAttribute;
import com.sun.xacml.ctx.Attribute;
import com.sun.xacml.ctx.RequestCtx;
import com.sun.xacml.ctx.ResponseCtx;
import com.sun.xacml.ctx.Result;
import com.sun.xacml.ctx.Subject;
import com.sun.xacml.finder.AttributeFinder;
import com.sun.xacml.finder.PolicyFinder;
import com.sun.xacml.finder.impl.CurrentEnvModule;
import com.sun.xacml.finder.impl.FilePolicyModule;


public class Servlet_xacml_old extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	File[] listaFile;//contiene le policy disponibili
    
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	// Inizializzo il PDP
    	File f;
        String policyfile;
        FilePolicyModule policyModule = new FilePolicyModule();
        PolicyFinder policyFinder = new PolicyFinder();
        Set policyModules = new HashSet();
        
        String PATH_POLICY = "/Users/frapiet/Desktop/progetto_gradle_esempio/src/main/resources/Policies"; //path della cartella contenente le policy
        cercaPolicyFile(new File(PATH_POLICY));
        
        for(int i=0;i<listaFile.length;i++)
        {
             f=listaFile[i];
             policyfile = f.getAbsolutePath();
             policyModule.addPolicy(policyfile);
             policyModules.add(policyModule);
             policyFinder.setModules(policyModules);
        }

        AttributeFinder attrFinder = new AttributeFinder();
        
        CurrentEnvModule envModule = new CurrentEnvModule();
        DBAttributeFinder dbAttributeFinder = new DBAttributeFinder();
        
        List attrModules = new ArrayList();
        attrModules.add(envModule);
        attrModules.add(dbAttributeFinder);
        
        attrFinder.setModules(attrModules);
    	
		// ricava gli attributi dalla post
		String id_utente_st = request.getParameter("id-utente");
		Integer id_utente = null;
		try {
			id_utente = Integer.parseInt(id_utente_st);
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println("Eccezione id-utente");
			id_utente = 0;
			}
		
		String resource_type = request.getParameter("resource-type");
		
		String id_lista_st = request.getParameter("id-lista");
		Integer id_lista = null;
		try {
			id_lista = Integer.parseInt(id_lista_st);
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println("Eccezione id-lista");
			id_lista = 0;
			}
		
		String id_gruppo_st = request.getParameter("id-gruppo");
		Integer id_gruppo = null;
		try {
			id_gruppo = Integer.parseInt(id_gruppo_st);
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println("Eccezione id-gruppo");
			id_gruppo = 0;
			}
		
		String action_type = request.getParameter("action-type");
		
		try {
			// costruisco i Subjects
			HashSet attributes = new HashSet();
	        HashSet subjects = new HashSet();
	            
	        attributes.add(new Attribute(new URI("urn:progetto:names:id-utente"),null, null,new IntegerAttribute(id_utente)));
	                
	        subjects.add(new Subject(attributes));
	        
	        //Resources
	        HashSet resources = new HashSet();
	
	        StringAttribute resource_type_attr = new StringAttribute(resource_type);
	        resources.add(new Attribute(new URI("urn:progetto:names:resource-type"),null, null, resource_type_attr));
	        
	        IntegerAttribute id_lista_attr = new IntegerAttribute(id_lista);
	        resources.add(new Attribute(new URI("urn:oasis:names:tc:xacml:1.0:resource:resource-id"),null, null, id_lista_attr));
	        resources.add(new Attribute(new URI("urn:progetto:names:id-lista"),null, null, id_lista_attr));
	        
	        IntegerAttribute id_gruppo_attr = new IntegerAttribute(id_gruppo);
	        resources.add(new Attribute(new URI("urn:progetto:names:id-gruppo"),null, null, id_gruppo_attr));
	        
	        //Actions
	        HashSet action = new HashSet();
	        
	        StringAttribute action_type_attr = new StringAttribute(action_type);
	        action.add(new Attribute(new URI("urn:progetto:names:action-type"),null, null, action_type_attr));
			
	        // Costruisce la richiesta
			RequestCtx XACMLrequest = new RequestCtx(subjects, resources, action, new HashSet());
			
			// inizializzo il PDP
			PDP pdp = new PDP(new PDPConfig(attrFinder, policyFinder, null));
			
	        ResponseCtx XACMLresponse = pdp.evaluate(XACMLrequest);
	        
	        // elaboro la decisione
	        Set ris_set = XACMLresponse.getResults();
	        Result ris = null;
	        Iterator it = ris_set.iterator();
	
	        while (it.hasNext()) {
	            ris = (Result) it.next();
	        }
	        int dec = ris.getDecision();
	        
	        if (dec == 0) {//permit
	        	response.sendRedirect(request.getContextPath()+"/logged_in/AccessAuthorized.jsp");
	        } else if (dec == 1) {//deny
	        	response.sendRedirect(request.getContextPath()+"/logged_in/AccessDenied.jsp");
	        } else if (dec == 2||dec==3) {//not applicable o indeterminate
	        	response.sendRedirect(request.getContextPath()+"/logged_in/AccessError.jsp");
	        }
		}
        catch (Exception ex) {
        	ex.printStackTrace();	
        }
		
	}
    
    private void cercaPolicyFile (File dir) {
    	listaFile = dir.listFiles(new FilenameFilter() {
    	    public boolean accept(File dir, String name) {
    	        return name.toLowerCase().endsWith(".xml");
    	    }
    	});
	}
}
