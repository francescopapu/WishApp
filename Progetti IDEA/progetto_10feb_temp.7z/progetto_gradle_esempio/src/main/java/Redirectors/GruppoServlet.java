package Redirectors;

import DataAccess.AccessProxy;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

/*
    -Serve per gestite le richieste GET (visione delle pagine via browser) e POST (pressione dei pulsanti)
    destinate alla pagina relativa a un gruppo
*/

@WebServlet(name = "GruppoServlet", urlPatterns = {"/logged_in/gruppo/"})
public class GruppoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[GruppoServlet] doGet");

        // Ricava l'oggetto session
        HttpSession session = request.getSession();

        // -Controlla se l'AccessProxy relativo alla sessione è già inizializzato e in caso contrario
        // lo inizializza
        AccessProxy access_proxy = (AccessProxy) session.getAttribute("access_proxy");
        if (access_proxy != null) {
            System.out.println("[GruppoServlet] AccessProxy presente");
        } else {
            access_proxy = new AccessProxy();
            session.setAttribute("access_proxy", access_proxy);
            System.out.println("[GruppoServlet] AccessProxy inizializzato");
        }

        // Verifica se l'operazione di visualizzazione è consentita
        // PARAMETRI STUB
        ArrayList<String> nomi_partecipanti = access_proxy.GetPartecipantsNames(123,234);
        // PARAMETRI STUB
        ArrayList<String> nomi_liste = access_proxy.GetSharedListsNames(123,234);
        if (nomi_partecipanti.size() == 1 || nomi_liste.size() == 1) {
            System.out.println("[GruppoServlet] Visualizzazione non autorizzata - nomi_liste: "+nomi_liste.get(0)+" - nomi_partecipanti: "+nomi_partecipanti.get(0));

            response.sendRedirect("/logged_in/dashboard/");
        }
        else {
            // Preleva i nomi dei partecipanti al gruppo corrente e le liste da loro condivise con il gruppo
            // e li inserisce nella richiesta che poi verrà inoltrata alla pagina .jsp
            request.setAttribute("nomi_partecipanti", nomi_partecipanti);
            request.setAttribute("nomi_liste", nomi_liste);

            // Inoltra la richiesta GET alla pagina .jsp corrispondente
            RequestDispatcher dispatcher = request.getRequestDispatcher("/logged_in/gruppo/Gruppo.jsp");
            if (dispatcher != null){
                dispatcher.forward(request, response);
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[GruppoServlet] doPost");

        // Estrae i parametri dalla richiesta POST
        String id_partecipante = request.getParameter("id_partecipante");
        String rimuovi_id_lista = request.getParameter("rimuovi_id_lista");
        String visualizza_id_lista = request.getParameter("visualizza_id_lista");
        String button_pushed = request.getParameter("button_pushed");

        // Ricava l'oggetto session
        HttpSession session = request.getSession();

        // Ricava le informazioni sull'utente, sulla lista e sul gruppo corrente dalla sessione
        //Integer id_utente = (Integer) session.getAttribute("id_utente");
        Integer id_gruppo = (Integer) session.getAttribute("id_gruppo");

        // Ricava l'access proxy relativo alla sessione
        AccessProxy access_proxy = (AccessProxy) session.getAttribute("access_proxy");

        // Effettua le operazioni opportune in base al pulsante premuto
        if (id_partecipante != null) {
            System.out.println("[GruppoServlet] Rimuovi id_partecipante: "+id_partecipante);

            // PARAMETRI STUB
            String result = access_proxy.RemovePartecipant(123, 123, 123);
            // String result = access_proxy.RemovePartecipant(id_utente, id_gruppo, id_partecipante);

            if (result.equals("Permit")) {//permit
                System.out.println("[GruppoServlet] Rimuovi partecipante permesso");
            } else if (result.equals("Deny")) {//deny
                System.out.println("[GruppoServlet] Rimuovi partecipante negato");
            } else if (result.equals("Indeterminate")) {//indeterminate
                System.out.println("[GruppoServlet] Rimuovi partecipante, valutazione xacml indeterminata");
            } else if (result.equals("NotApplicable")) {//not applicable
                System.out.println("[GruppoServlet] Rimuovi partecipante, nessuna policy xacml applicabile");
            }

            response.sendRedirect("/logged_in/gruppo/");
        }
        if (rimuovi_id_lista != null) {
            System.out.println("[GruppoServlet] Rimuovi id_lista: "+rimuovi_id_lista);

            // PARAMETRI STUB
            String result = access_proxy.RemoveList(123, 123,123);
            // String result = access_proxy.RemoveList(id_utente, rimuovi_id_lista, id_gruppo);

            if (result.equals("Permit")) {//permit
                System.out.println("[GruppoServlet] Elimina lista permesso");
            } else if (result.equals("Deny")) {//deny
                System.out.println("[GruppoServlet] Elimina lista negato");
            } else if (result.equals("Indeterminate")) {//indeterminate
                System.out.println("[GruppoServlet] Elimina lista, valutazione xacml indeterminata");
            } else if (result.equals("NotApplicable")) {//not applicable
                System.out.println("[GruppoServlet] Elimina lista, nessuna policy xacml applicabile");
            }

            response.sendRedirect("/logged_in/gruppo/");
        }
        if (visualizza_id_lista != null) {
            System.out.println("[GruppoServlet] Visualizza id_lista: "+visualizza_id_lista);

            // Inserisco nell'oggetto session l'id della lista corrente e il suo tipo
            session.setAttribute("id_lista",visualizza_id_lista);
            session.setAttribute("tipo_lista", "Condivisa");

            response.sendRedirect("/logged_in/lista/");
        }
        if (button_pushed != null) {
            if (button_pushed.equals("rinomina_gruppo")) {
                System.out.println("[GruppoServlet] Rinomina gruppo");

                // TO DO (per la rinomina si dovrebbe andare a un'altra pagina dove inserire il nuovo nome)

                // PARAMETRI STUB
                String result = access_proxy.RenameGroup(123, 123, "nome");
                // String result = access_proxy.RenameGroup(id_utente, id_gruppo, "nome");

                if (result.equals("Permit")) {//permit
                    System.out.println("[GruppoServlet] Rinomina gruppo permesso");
                } else if (result.equals("Deny")) {//deny
                    System.out.println("[GruppoServlet] Rinomina gruppo negato");
                } else if (result.equals("Indeterminate")) {//indeterminate
                    System.out.println("[GruppoServlet] Rinomina gruppo, valutazione xacml indeterminata");
                } else if (result.equals("NotApplicable")) {//not applicable
                    System.out.println("[GruppoServlet] Rinomina gruppo, nessuna policy xacml applicabile");
                }

                response.sendRedirect("/logged_in/gruppo/");
            }
            else if (button_pushed.equals("elimina_gruppo")) {
                System.out.println("[GruppoServlet] Elimina gruppo");

                // PARAMETRI STUB
                String result = access_proxy.RemoveGroup(123, 123);
                // String result = access_proxy.RemoveGroup(id_utente, id_gruppo);
                // session.setAttribute("id_gruppo",0); // oppure null

                if (result.equals("Permit")) {//permit
                    System.out.println("[GruppoServlet] Elimina gruppo permesso");
                } else if (result.equals("Deny")) {//deny
                    System.out.println("[GruppoServlet] Elimina gruppo negato");
                } else if (result.equals("Indeterminate")) {//indeterminate
                    System.out.println("[GruppoServlet] Elimina gruppo, valutazione xacml indeterminata");
                } else if (result.equals("NotApplicable")) {//not applicable
                    System.out.println("[GruppoServlet] Elimina gruppo, nessuna policy xacml applicabile");
                }

                response.sendRedirect("/logged_in/dashboard/");
            }
            else if (button_pushed.equals("aggiungi_partecipante")) {
                System.out.println("[GruppoServlet] Aggiungi partecipante");

                // PARAMETRI STUB
                String result = access_proxy.AddPartecipant(123, 123, 123);
                // String result = access_proxy.AddPartecipant(id_utente, id_gruppo, 123);
                // per implementare del tutto bisognerebbe permettere la ricerca e selezione di un utente

                if (result.equals("Permit")) {//permit
                    System.out.println("[GruppoServlet] Aggiungi partecipante permesso");
                } else if (result.equals("Deny")) {//deny
                    System.out.println("[GruppoServlet] Aggiungi partecipante negato");
                } else if (result.equals("Indeterminate")) {//indeterminate
                    System.out.println("[GruppoServlet] Aggiungi partecipante, valutazione xacml indeterminata");
                } else if (result.equals("NotApplicable")) {//not applicable
                    System.out.println("[GruppoServlet] Aggiungi partecipante, nessuna policy xacml applicabile");
                }

                response.sendRedirect("/logged_in/gruppo/");
            }
        }
    }
}