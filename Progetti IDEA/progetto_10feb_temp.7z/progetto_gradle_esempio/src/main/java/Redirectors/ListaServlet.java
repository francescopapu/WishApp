package Redirectors;

import DataAccess.AccessProxy;
import PersistentObjs.Lista;
import PersistentObjs.Prodotto;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

/*
    -Serve per gestite le richieste GET (visione delle pagine via browser) e POST (pressione dei pulsanti)
    destinate alla pagina relativa a una lista
*/

@WebServlet(name = "ListaServlet", urlPatterns = {"/logged_in/lista/"})
public class ListaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[ListaServlet] doGet");

        // Ricava l'oggetto session
        HttpSession session = request.getSession();

        // -Controlla se l'AccessProxy relativo alla sessione è già inizializzato e in caso contrario
        // lo inizializza
        AccessProxy access_proxy = (AccessProxy) session.getAttribute("access_proxy");
        if (access_proxy != null) {
            System.out.println("[ListaServlet] AccessProxy presente");
        } else {
            access_proxy = new AccessProxy();
            session.setAttribute("access_proxy", access_proxy);
            System.out.println("[ListaServlet] AccessProxy inizializzato");
        }

        // Ricava le informazioni sull'utente, sulla lista e sul gruppo corrente dalla sessione
        //Integer id_utente = (Integer) session.getAttribute("id_utente");
        Integer id_lista = (Integer) session.getAttribute("id_lista");
        Integer id_gruppo = (Integer) session.getAttribute("id_gruppo");
        String tipo_lista = (String) session.getAttribute("tipo_lista");

        // Verifica se l'operazione di visualizzazione è consentita
        if (tipo_lista != null) {
            if (tipo_lista.equals("Personale")){
                id_gruppo = 0; // oppure null
            }
        }
        // PARAMETRI STUB
        ArrayList<Lista> liste = access_proxy.GetList(123,id_lista, id_gruppo);
        String result = liste.get(0).getNome();
        if (result.equals("Permit")) {
            Lista lista = liste.get(1);

            // Preleva i nomi degli oggetti contenuti nella lista corrente e li inserisce nella richiesta
            // che poi verrà inoltrata alla pagina .jsp
            request.setAttribute("lista", lista);

            // Inoltra la richiesta GET alla pagina .jsp corrispondente
            RequestDispatcher dispatcher = request.getRequestDispatcher("/logged_in/lista/Lista.jsp");
            if (dispatcher != null){
                dispatcher.forward(request, response);
            }
        } else {
            System.out.println("[ListaServlet] Visualizzazione non autorizzata: "+result);

            response.sendRedirect("/logged_in/dashboard/");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("[ListaServlet] doPost");

        // Ricava i parametri dalla richiesta POST
        String id_prodotto = request.getParameter("id_prodotto");
        String button_pushed = request.getParameter("button_pushed");

        // Ricava l'oggetto session
        HttpSession session = request.getSession();

        // Ricava le informazioni sull'utente, sulla lista e sul gruppo corrente dalla sessione
        //Integer id_utente = (Integer) session.getAttribute("id_utente");
        Integer id_lista = (Integer) session.getAttribute("id_lista");
        Integer id_gruppo = (Integer) session.getAttribute("id_gruppo");
        String tipo_lista = (String) session.getAttribute("tipo_lista");

        // Ricava l'access proxy relativo alla sessione
        AccessProxy access_proxy = (AccessProxy) session.getAttribute("access_proxy");

        // Effettua le operazioni opportune in base al pulsante premuto
        if (id_prodotto != null) {
            System.out.println("[ListaServlet] Rimuovi id_prodotto: "+id_prodotto);

            // Converto l'attributo in intero
            Integer id_prodotto_int = Integer.parseInt(id_prodotto);

            // PARAMETRI STUB
            String result = access_proxy.RemoveElement(123, 123, 123, 123);
            /*
            if (tipo_lista != null) {
                if (tipo_lista.equals("Personale")){
                    id_gruppo = 0; // oppure null
                }
            }
            String result = access_proxy.RemoveElement(id_utente, id_lista, id_gruppo, id_prodotto_int);
             */

            if (result.equals("Permit")) {//permit
                System.out.println("[ListaServlet] Rinomina lista permesso");
            } else if (result.equals("Deny")) {//deny
                System.out.println("[ListaServlet] Rinomina lista negato");
            } else if (result.equals("Indeterminate")) {//indeterminate
                System.out.println("[ListaServlet] Rinomina lista, valutazione xacml indeterminata");
            } else if (result.equals("NotApplicable")) {//not applicable
                System.out.println("[ListaServlet] Rinomina lista, nessuna policy xacml applicabile");
            }

            response.sendRedirect("/logged_in/lista/");
        }
        if (button_pushed != null) {
            if (button_pushed.equals("rinomina_lista")) {
                System.out.println("[ListaServlet] Rinomina lista");

                // TO DO (per la rinomina si dovrebbe andare a un'altra pagina dove inserire il nuovo nome)

                // PARAMETRI STUB
                String result = access_proxy.RenameList(123, 123, 123, "nome");
                /*
                if (tipo_lista != null) {
                    if (tipo_lista.equals("Personale")){
                        id_gruppo = 0; // oppure null
                    }
                }
                String result = access_proxy.RenameList(id_utente, id_lista, id_gruppo, "nome");
                */

                if (result.equals("Permit")) {//permit
                    System.out.println("[ListaServlet] Rinomina lista permesso");
                } else if (result.equals("Deny")) {//deny
                    System.out.println("[ListaServlet] Rinomina lista negato");
                } else if (result.equals("Indeterminate")) {//indeterminate
                    System.out.println("[ListaServlet] Rinomina lista, valutazione xacml indeterminata");
                } else if (result.equals("NotApplicable")) {//not applicable
                    System.out.println("[ListaServlet] Rinomina lista, nessuna policy xacml applicabile");
                }

                response.sendRedirect("/logged_in/lista/");
            }
            else if (button_pushed.equals("elimina_lista")) {
                System.out.println("[ListaServlet] Elimina lista");

                // PARAMETRI STUB
                String result = access_proxy.RemoveList(123, 123,123);
                /*
                if (tipo_lista != null) {
                    if (tipo_lista.equals("Personale")){
                        id_gruppo = 0; // oppure null
                    }
                }
                String result = access_proxy.RemoveList(id_utente, id_lista, id_gruppo);
                // session.setAttribute("id_lista",0); // oppure null
                */

                if (result.equals("Permit")) {//permit
                    System.out.println("[ListaServlet] Elimina lista permesso");
                } else if (result.equals("Deny")) {//deny
                    System.out.println("[ListaServlet] Elimina lista negato");
                } else if (result.equals("Indeterminate")) {//indeterminate
                    System.out.println("[ListaServlet] Elimina lista, valutazione xacml indeterminata");
                } else if (result.equals("NotApplicable")) {//not applicable
                    System.out.println("[ListaServlet] Elimina lista, nessuna policy xacml applicabile");
                }

                // TO DO (oppure tornare alla pagina precedente: gruppo o dashboard)
                response.sendRedirect("/logged_in/dashboard/");
            }
            else if (button_pushed.equals("aggiungi_oggetto")) {
                System.out.println("[ListaServlet] Aggiungi oggetto");

                // TO DO (per aggiungere si dovrebbe andare a un'altra pagina dove inserire il nome dell'oggetto)

                // PARAMETRI STUB
                String result = access_proxy.AddElement(123, 123,123,"nome");
                /*
                if (tipo_lista != null) {
                    if (tipo_lista.equals("Personale")){
                        id_gruppo = 0; // oppure null
                    }
                }
                String result = access_proxy.AddElement(id_utente, id_lista, id_gruppo, "nome");
                */

                if (result.equals("Permit")) {//permit
                    System.out.println("[ListaServlet] Aggiungi oggetto permesso");
                } else if (result.equals("Deny")) {//deny
                    System.out.println("[ListaServlet] Aggiungi oggetto negato");
                } else if (result.equals("Indeterminate")) {//indeterminate
                    System.out.println("[ListaServlet] Aggiungi oggetto, valutazione xacml indeterminata");
                } else if (result.equals("NotApplicable")) {//not applicable
                    System.out.println("[ListaServlet] Aggiungi oggetto, nessuna policy xacml applicabile");
                }

                response.sendRedirect("/logged_in/lista/");
            }
        }
    }
}