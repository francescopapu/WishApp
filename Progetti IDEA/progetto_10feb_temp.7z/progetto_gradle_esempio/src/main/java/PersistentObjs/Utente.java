package PersistentObjs;

public class Utente {
    private Integer Id;
    private String Nome;
    private String Cognome;


    public Utente(Integer id, String nome) {
        Id = id;
        Nome = nome;
    }

    public Integer getId() {
        return Id;
    }

    public String getNome() {
        return Nome;
    }

    public String getCognome() {
        return Cognome;
    }
}
