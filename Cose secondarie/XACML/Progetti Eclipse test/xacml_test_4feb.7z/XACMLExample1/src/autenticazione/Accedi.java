package autenticazione;
import org.apache.commons.codec.digest.DigestUtils;
import java.io.IOException;
import java.sql.*;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Accedi
 */
public class Accedi extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Accedi() {
    	
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//NOTA: in mancanza di una procedura di registrazione ho usato le seguenti 
		//istruzioni per generare gli hash delle password da mettere nel db
		//al posto delle password in chiaro; aggiungendo la procedura di registrazione
		//le password verrebbero trasformate dopo che l'utente le ha inserite in un form
				
		//String userpw = DigestUtils.sha256Hex("user");
		//String adminpw = DigestUtils.sha256Hex("admin");
		
		
		
		//parametri presi dal form di login:
		String username = request.getParameter("username");
	    String password = request.getParameter("password");
	    System.out.println("password da form: "+password);
	    
	    //calcolo l'hash per poterlo confrontare con il contenuto
	    //del db:
	    String hashedpass = DigestUtils.sha256Hex(password);
	    System.out.println("password hashed: "+hashedpass);	
	    
	    
	    boolean isAuthenticated=false;
	    
	    String nome = "";
	    String ruolo = "";
	    String passdb = "";
	    /*try {

            Connection dbconn = null;
            Class.forName("com.mysql.jdbc.Driver");
            dbconn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_esercitazione", "myuser", "mypass");
            dbconn.setAutoCommit(true);
            Statement statement = dbconn.createStatement();

            String query = new String("SELECT password,nome,ruolo FROM db_esercitazione.utenti  WHERE username='"+username+"'");
            
            ResultSet result = statement.executeQuery(query);
	            
	            while(result.next()){
	            	
	            	passdb = result.getString("password");
	            	System.out.println("password da db: "+passdb);	
	            	
	            	//controllo se l'hash della password appena calcolato
	            	//� uguale a quello contenuto nel db
	        	    if(passdb.equals(hashedpass)){
	            		System.out.println("Utente autenticato!");
	            		isAuthenticated = true;
	            		nome = result.getString("nome");
	            		ruolo = result.getString("ruolo");
	               }
	            	else
	                	System.out.println("autenticazione fallita!");
            }	
            

            statement.close();
            dbconn.close();
	    }
            
             catch (ClassNotFoundException e) {
                   e.printStackTrace();
             }
             catch (SQLException ex) {
                   ex.printStackTrace();
             }
        */
	    
	    //per prova senza db
	    isAuthenticated=true;
	    
	    if(username.equals("user")){
	    	nome="Alessandra";
	    	ruolo="utente";
	    }
	    else if(username.equals("admin")){
	    	nome="Valentina";
	    	ruolo="amministratore";
	    }
	  
	    
        if(isAuthenticated){    
        	HttpSession sessione = request.getSession();
        	sessione.setAttribute("utente", nome);
        	sessione.setAttribute("ruolo", ruolo);
	    
        	request.getRequestDispatcher( "/pagine/home_liste.jsp" ).forward(request,response);
        } 
        else{
        	HttpSession sessione = request.getSession();
        	sessione.setAttribute("error","Login failed. Retry.");
        	request.getRequestDispatcher( "/login.jsp" ).forward(request,response);

        }
	}

}
