package Authentication;

import DataAccess.AccessProxy;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "AdminServlet", urlPatterns = {"/logged_in/admin/*"})
public class AdminServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        handle(req,res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        handle(req,res);
    }

    protected void handle(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Boolean isAdmin = (Boolean) session.getAttribute("isAdmin");
        if (isAdmin != null) {
            if (isAdmin) {
                System.out.println("[AdminServlet - handle] utente amministratore");
                res.sendRedirect("/logged_in/admin/AccessAuthorized.jsp");
            } else {
                System.out.println("[AdminServlet - handle] utente non amministratore");
                res.sendRedirect("/logged_in/dashboard");
            }
        }
    }
}
