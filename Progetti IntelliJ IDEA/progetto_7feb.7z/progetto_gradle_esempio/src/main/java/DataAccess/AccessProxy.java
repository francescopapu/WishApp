package DataAccess;

import java.util.ArrayList;

public class AccessProxy {

    /*
    Serve per ricavare i nomi delle liste di cui è proprietario l'utente
     */
    public static ArrayList<String> GetPersonalListsNames(Integer id_utente) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome lista 1");
        String name_2 = new String("Nome lista 2");
        String name_3 = new String("Nome lista 3");

        ArrayList<String> names = new ArrayList<String>();
        names.add(name_1);
        names.add(name_2);
        names.add(name_3);

        return names;
    }

    /*
    Server per ricavare i nomi dei gruppi di cui l'utente è proprietario o a cui partecipa
     */
    public static ArrayList<String> GetPersonalGroupsNames(Integer id_utente) {

        // STUB dell'accesso al DB
        String name_1 = new String("Nome gruppo 1");
        String name_2 = new String("Nome gruppo 2");
        String name_3 = new String("Nome gruppo 3");

        ArrayList<String> names = new ArrayList<String>();
        names.add(name_1);
        names.add(name_2);
        names.add(name_3);

        return names;
    }

    /*
    Serve per inserire una nuova lista vuota nel DB
     */
    public Boolean NewList(String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per inserire un nuovo gruppo vuoto nel DB
     */
    public Boolean NewGroup(String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per ottenere i nomi degli oggetti contenuti in una lista
     */
    public ArrayList<String> GetObjectsNames(Integer id_utente, Integer id_lista) {
        // TO DO
        return new ArrayList<String>();
    }

    /*
    Serve per rimuovere una lista dal DB
     */
    public Boolean RemoveList(Integer id_utente, Integer id_lista) {
        // TO DO
        return true;
    }

    /*
    Serve per rinominare una lista nel DB
     */
    public Boolean RenameList(Integer id_utente, Integer id_lista, String nuovo_nome) {
        // TO DO
        return true;
    }

    /*
    Serve per aggiungere un elemento ad una lista nel DB
     */
    public Boolean AddElement(Integer id_utente, Integer id_lista, String nome) {
        // TO DO
        return true;
    }

    /*
    Serve per rimuovere un elemento da una lista nel DB
     */
    public Boolean RemoveElement(Integer id_utente, Integer id_lista, Integer id_elemento) {
        // TO DO
        return true;
    }

    /*
    Serve per ricavare i nomi dei partecipanti a un gruppo dal DB
     */
    public ArrayList<String> GetPartecipantsNames(Integer id_utente, Integer id_gruppo) {
        // TO DO
        return new ArrayList<String>();
    }

    /*
    Serve per ricavare i nomi delle liste condivise con un gruppo dal DB
     */
    public ArrayList<String> GetSharedListsNames(Integer id_utente, Integer id_gruppo) {
        // TO DO
        return new ArrayList<String>();
    }

    /*
    Serve per aggiungere partecipanti a un gruppo sul DB
     */
    public Boolean AddPartecipant(Integer id_utente, Integer id_gruppo, Integer id_nuovo_utente) {
        // TO DO
        return true;
    }

    /*
    Serve per rimuovere un partecipante da un gruppo sul DB
     */
    public Boolean RemovePartecipant (Integer id_utente, Integer id_gruppo, Integer id_utente_eliminato) {
        // TO DO
        return true;
    }

}
